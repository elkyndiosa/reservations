<?php
class ErrorController{
    public function index(){
        echo '<div class="page-not d-flex justify-content-center align-items-center"><h1>Error al encontrar la pagina</h1></div>';
    }
}