</div>
</div>
</div>
</div>
<footer class="text-center bg-info py-2 text-light fixed-bottom">
    <p class="mb-0">Desarrollado por Gustavo Diosa &COPY; <?= date('Y') ?></p>
</footer>
<script type="text/javascript"  src=" <?=base_url?>assets/js/overhang.min.js"> </script>
</body>
</html>
