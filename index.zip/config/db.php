
<?php 
class database{
    public static function connect(){
        $db = new mysqli('localhost', 'gustavo', '12345', 'reservas');
        $db-> query("SET NAMES 'utf8'");
        return $db;
    }
}




//class database{
//    public static function connect(){
//        $db = new mysqli('localhost', 'root', '', 'reservation');
//        $db-> query("SET NAMES 'utf8'");
//        return $db;
//    }
