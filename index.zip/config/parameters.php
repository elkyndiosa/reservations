<?php
define('base_url', 'http://localhost/ReserverManager/');
define('controller_default', 'reservationController');
define('action_default', 'index');
date_default_timezone_set("America/Bogota");
