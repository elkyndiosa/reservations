<?php
define ( 'base_url' , 'https://gustavodiosa.com/' );
define ( 'controller_default' , 'reserveController' );
define ( 'action_default' , 'index' );
date_default_timezone_set ( "Am�rica / Bogot�" );

//define('base_url', 'http://localhost/reservermanager/');
//define('controller_default', 'reservationController');
//define('action_default', 'index');
//date_default_timezone_set("America/Bogota");
